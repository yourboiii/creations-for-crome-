window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Gerne finder 2.0",
   "version": "0.2",
   "homepage": "https://www.randomanime.org/",
   "enableNavBttns": false,
   "enableHomeBttn": true,
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "rotation": "0",
   "kioskEnabled": false
};